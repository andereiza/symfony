<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Bmw;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;use Symfony\Component\HttpFoundation\Request;

/**
 * Bmw controller.
 *
 * @Route("bmw")
 */
class BmwController extends Controller
{
    /**
     * Lists all bmw entities.
     *
     * @Route("/", name="bmw_index")
     * @Method({"GET", "POST"})
     */
    public function indexAction(Request $request)
    {
        $em = $this->getDoctrine()->getManager();
if ($request->getMethod() == 'POST')
    {

    $modelo= $request->request->get('modelo');
     $bmws = $em->getRepository('AppBundle:Bmw')->findBy(array('modelo'=>$modelo));
             if (! $bmws) {
                echo "No se encuentran entradas con ese modelo: ", $modelo;
                echo "<br>Aqui tienes la lista entera";
                $bmws = $em->getRepository('AppBundle:Bmw')->findAll();
        }
        }
        
        else
       
        $bmws = $em->getRepository('AppBundle:Bmw')->findAll();

        return $this->render('bmw/index.html.twig', array(
            'bmws' => $bmws,
        ));

    }

    /**
     * Creates a new bmw entity.
     *
     * @Route("/new", name="bmw_new")
     * @Method({"GET", "POST"})
     */
    public function newAction(Request $request)
    {
        $bmw = new Bmw();
        $form = $this->createForm('AppBundle\Form\BmwType', $bmw);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->persist($bmw);
            $em->flush();

            return $this->redirectToRoute('bmw_show', array('codcoche' => $bmw->getCodcoche()));
        }

        return $this->render('bmw/new.html.twig', array(
            'bmw' => $bmw,
            'form' => $form->createView(),
        ));
    }

    /**
     * Finds and displays a bmw entity.
     *
     * @Route("/{codcoche}", name="bmw_show")
     * @Method("GET")
     */
    public function showAction(Bmw $bmw)
    {
        $deleteForm = $this->createDeleteForm($bmw);

        return $this->render('bmw/show.html.twig', array(
            'bmw' => $bmw,
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Displays a form to edit an existing bmw entity.
     *
     * @Route("/{codcoche}/edit", name="bmw_edit")
     * @Method({"GET", "POST"})
     */
    public function editAction(Request $request, Bmw $bmw)
    {
        $deleteForm = $this->createDeleteForm($bmw);
        $editForm = $this->createForm('AppBundle\Form\BmwType', $bmw);
        $editForm->handleRequest($request);

        if ($editForm->isSubmitted() && $editForm->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('bmw_edit', array('codcoche' => $bmw->getCodcoche()));
        }

        return $this->render('bmw/edit.html.twig', array(
            'bmw' => $bmw,
            'edit_form' => $editForm->createView(),
            'delete_form' => $deleteForm->createView(),
        ));
    }

    /**
     * Deletes a bmw entity.
     *
     * @Route("/{codcoche}", name="bmw_delete")
     * @Method("DELETE")
     */
    public function deleteAction(Request $request, Bmw $bmw)
    {
        $form = $this->createDeleteForm($bmw);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $em = $this->getDoctrine()->getManager();
            $em->remove($bmw);
            $em->flush();
        }

        return $this->redirectToRoute('bmw_index');
    }

    /**
     * Creates a form to delete a bmw entity.
     *
     * @param Bmw $bmw The bmw entity
     *
     * @return \Symfony\Component\Form\Form The form
     */
    private function createDeleteForm(Bmw $bmw)
    {
        return $this->createFormBuilder()
            ->setAction($this->generateUrl('bmw_delete', array('codcoche' => $bmw->getCodcoche())))
            ->setMethod('DELETE')
            ->getForm()
        ;
    }
}

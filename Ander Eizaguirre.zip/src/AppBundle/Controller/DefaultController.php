<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class DefaultController extends Controller
{
    /**
     * @Route("/", name="homepage")
     */
    public function indexAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/index.html.twig', [
            'base_dir' => realpath($this->getParameter('kernel.project_dir')).DIRECTORY_SEPARATOR,
        ]);
    }       

      /**
     * @Route("/inicio", name="inicio")
     */
    
    public function inicioAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/inicio.html.twig', [
            'base_dir' => realpath($this->getParameter('kernel.project_dir')).DIRECTORY_SEPARATOR,
        ]);
    }
      /**
     * @Route("/historia", name="historia")
     */
    
    public function historiaAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/historia.html.twig', [
            'base_dir' => realpath($this->getParameter('kernel.project_dir')).DIRECTORY_SEPARATOR,
        ]);
    }
      /**
     * @Route("/pagina2", name="pagina2")
     */
    
    public function pagina2Action(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/pagina2.html.twig', [
            'base_dir' => realpath($this->getParameter('kernel.project_dir')).DIRECTORY_SEPARATOR,
        ]);
    }
      /**
     * @Route("/pagina3", name="pagina3")
     */
    
    public function pagina3Action(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/pagina3.html.twig', [
            'base_dir' => realpath($this->getParameter('kernel.project_dir')).DIRECTORY_SEPARATOR,
        ]);
    }
      /**
     * @Route("/pagina4", name="pagina4")
     */
    
    public function pagina4Action(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/pagina4.html.twig', [
            'base_dir' => realpath($this->getParameter('kernel.project_dir')).DIRECTORY_SEPARATOR,
        ]);
    }
         /**
     * @Route("/pagina5", name="pagina5")
     */
    
    public function pagina5Action(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/pagina5.html.twig', [
            'base_dir' => realpath($this->getParameter('kernel.project_dir')).DIRECTORY_SEPARATOR,
        ]);
    }
          /**
     * @Route("/formulario", name="formulario")
     */
    
    public function formularioAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/formulario.html.twig', [
            'base_dir' => realpath($this->getParameter('kernel.project_dir')).DIRECTORY_SEPARATOR,
        ]);
    }
           /**
     * @Route("/editaryeliminar", name="editaryeliminar")
     */
    
    public function editaryeliminarAction(Request $request)
    {
        // replace this example code with whatever you need
        return $this->render('default/editaryeliminar.html.twig', [
            'base_dir' => realpath($this->getParameter('kernel.project_dir')).DIRECTORY_SEPARATOR,
        ]);
    }
    
    
}

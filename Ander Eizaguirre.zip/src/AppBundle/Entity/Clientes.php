<?php

namespace AppBundle\Entity;

/**
 * Clientes
 */
class Clientes
{
    /**
     * @var string
     */
    private $pass;

    /**
     * @var string
     */
    private $usuarios;


    /**
     * Set pass
     *
     * @param string $pass
     *
     * @return Clientes
     */
    public function setPass($pass)
    {
        $this->pass = $pass;

        return $this;
    }

    /**
     * Get pass
     *
     * @return string
     */
    public function getPass()
    {
        return $this->pass;
    }

    /**
     * Get usuarios
     *
     * @return string
     */
    public function getUsuarios()
    {
        return $this->usuarios;
    }
}


<?php

namespace AppBundle\Entity;

/**
 * Bmw1
 */
class Bmw1
{
    /**
     * @var string
     */
    private $marca;

    /**
     * @var string
     */
    private $modelo;

    /**
     * @var string
     */
    private $año;

    /**
     * @var integer
     */
    private $codcoche;


    /**
     * Set marca
     *
     * @param string $marca
     *
     * @return Bmw1
     */
    public function setMarca($marca)
    {
        $this->marca = $marca;

        return $this;
    }

    /**
     * Get marca
     *
     * @return string
     */
    public function getMarca()
    {
        return $this->marca;
    }

    /**
     * Set modelo
     *
     * @param string $modelo
     *
     * @return Bmw1
     */
    public function setModelo($modelo)
    {
        $this->modelo = $modelo;

        return $this;
    }

    /**
     * Get modelo
     *
     * @return string
     */
    public function getModelo()
    {
        return $this->modelo;
    }

    /**
     * Set año
     *
     * @param string $año
     *
     * @return Bmw1
     */
    public function setAño($año)
    {
        $this->año = $año;

        return $this;
    }

    /**
     * Get año
     *
     * @return string
     */
    public function getAño()
    {
        return $this->año;
    }

    /**
     * Get codcoche
     *
     * @return integer
     */
    public function getCodcoche()
    {
        return $this->codcoche;
    }
}


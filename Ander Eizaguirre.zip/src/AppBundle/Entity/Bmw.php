<?php

namespace AppBundle\Entity;

/**
 * Bmw
 */
class Bmw
{
    /**
     * @var string
     */
    private $modelo;

    /**
     * @var string
     */
    private $anio;

    /**
     * @var integer
     */
    private $codcoche;


    /**
     * Set modelo
     *
     * @param string $modelo
     *
     * @return Bmw
     */
    public function setModelo($modelo)
    {
        $this->modelo = $modelo;

        return $this;
    }

    /**
     * Get modelo
     *
     * @return string
     */
    public function getModelo()
    {
        return $this->modelo;
    }

    /**
     * Set anio
     *
     * @param string $anio
     *
     * @return Bmw
     */
    public function setAnio($anio)
    {
        $this->anio = $anio;

        return $this;
    }

    /**
     * Get anio
     *
     * @return string
     */
    public function getAnio()
    {
        return $this->anio;
    }

    /**
     * Get codcoche
     *
     * @return integer
     */
    public function getCodcoche()
    {
        return $this->codcoche;
    }
}

